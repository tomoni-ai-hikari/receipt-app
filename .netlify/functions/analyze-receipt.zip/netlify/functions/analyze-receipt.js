var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/analyze-receipt.mjs
var analyze_receipt_exports = {};
__export(analyze_receipt_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(analyze_receipt_exports);
function parseReceiptText(text) {
  const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
  let date = null;
  for (const line of lines) {
    let m = line.match(/令和\s*(\d+)年\s*(\d{1,2})月\s*(\d{1,2})日/);
    if (m) {
      date = `${2018 + +m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
      break;
    }
    m = line.match(/R(\d+)[.\/\-](\d{1,2})[.\/\-](\d{1,2})/);
    if (m) {
      date = `${2018 + +m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
      break;
    }
    m = line.match(/(\d{4})[年\/\-](\d{1,2})[月\/\-](\d{1,2})日?/);
    if (m) {
      date = `${m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
      break;
    }
  }
  let amount = null;
  const totalKw = /合[　 ]?計|お会計|請求[　 ]?額|お支払[　 ]?金額|total/i;
  for (const line of lines) {
    if (totalKw.test(line)) {
      const m = line.match(/([1-9][0-9,]*)/);
      if (m) {
        amount = parseInt(m[1].replace(/,/g, ""), 10);
        if (amount > 0) break;
      }
    }
  }
  if (!amount) {
    let max = 0;
    for (const line of lines) {
      for (const m of line.matchAll(/[¥￥]?\s*([1-9][0-9,]{2,})/g)) {
        const v = parseInt(m[1].replace(/,/g, ""), 10);
        if (v > max) max = v;
      }
    }
    if (max > 0) amount = max;
  }
  let storeName = null;
  const skipLine = [
    /^[\d\s\-\/\.]+$/,
    /^[¥￥]/,
    /^(領収書|御領収書|レシート|receipt)/i,
    /^(tel|fax|〒|\d{3}[-\d])/i,
    /合計|小計|税/
  ];
  for (const line of lines) {
    if (line.length < 2) continue;
    if (skipLine.some((p) => p.test(line))) continue;
    storeName = line;
    break;
  }
  return { date, amount, storeName };
}
var headers = { "Content-Type": "application/json" };
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  try {
    const { imageData } = JSON.parse(event.body);
    if (!imageData) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: "\u753B\u50CF\u30C7\u30FC\u30BF\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093" }) };
    }
    const apiKey = process.env.GOOGLE_VISION_API_KEY;
    if (!apiKey) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: "GOOGLE_VISION_API_KEY \u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093" }) };
    }
    const visionRes = await fetch(
      `https://vision.googleapis.com/v1/images:annotate?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requests: [{
            image: { content: imageData },
            features: [{ type: "TEXT_DETECTION" }]
          }]
        })
      }
    );
    const visionData = await visionRes.json();
    if (visionData.error) throw new Error(visionData.error.message);
    const fullText = visionData.responses?.[0]?.fullTextAnnotation?.text ?? "";
    if (!fullText) {
      return { statusCode: 200, headers, body: JSON.stringify({ date: null, amount: null, storeName: null }) };
    }
    return { statusCode: 200, headers, body: JSON.stringify(parseReceiptText(fullText)) };
  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: e.message }) };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
